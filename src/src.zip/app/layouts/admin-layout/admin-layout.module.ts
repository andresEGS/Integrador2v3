import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AdminLayoutRoutes } from './admin-layout.routing';
import { DashboardComponent } from '../../dashboard/dashboard.component';
import { UserProfileComponent } from '../../user-profile/user-profile.component';
import { TableListComponent } from '../../table-list/table-list.component';
import { TypographyComponent } from '../../typography/typography.component';
import { IconsComponent } from '../../icons/icons.component';
import { MapsComponent } from '../../maps/maps.component';
import { NotificationsComponent } from '../../notifications/notifications.component';
import { UpgradeComponent } from '../../upgrade/upgrade.component';


import { PrincipalComponent } from 'app/principal/principal.component';
import { PiezasComponent } from 'app/piezas/piezas.component';
import { PedidosComponent } from 'app/pedidos/pedidos.component';
import { UsuariosComponent } from 'app/usuarios/usuarios.component';
import { GraficasComponent } from 'app/graficas/graficas.component';

import { Page404Component } from 'app/page404/page404.component';

import {
  MatButtonModule,
  MatInputModule,
  MatRippleModule,
  MatFormFieldModule,
  MatTooltipModule,
  MatSelectModule,
  MatDividerModule,
  MatSlideToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatRadioModule,
  MatListModule,
  MatIconModule,
  MatGridListModule,
  MatTabsModule,
  MatButtonToggleModule,
  
} from '@angular/material';
import { CommonModule } from '@angular/common';
import { ModalModule } from 'angular-bootstrap-md';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  imports: [
    RouterModule.forChild(AdminLayoutRoutes),
    CommonModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatRippleModule,
    MatInputModule,
    MatSelectModule,
    MatTooltipModule,
    MatSlideToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatRadioModule,
    MatDividerModule,
    MatListModule,
    ModalModule,
    NgbModule,
    MatIconModule,
    MatGridListModule,
    MatTabsModule,
    MatButtonToggleModule,
  ],
  declarations: [
    PrincipalComponent,
    PiezasComponent,
    PedidosComponent,
    UsuariosComponent,
    GraficasComponent,
    DashboardComponent,
    UserProfileComponent,
    TableListComponent,
    TypographyComponent,
    IconsComponent,
    MapsComponent,
    NotificationsComponent,
    UpgradeComponent
    
  ]
})

export class AdminLayoutModule {}
