import { Component, OnInit } from '@angular/core';
import { PedidosService } from 'app/services/pedidos.service';
import { PiezasService } from 'app/services/pieza.service';
import { UsuarioService } from 'app/services/usuario.service';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { Messages } from 'app/utilidades/Messages';
import { TextTilUtil } from 'app/utilidades/TextTilUtil';
import { Medida } from 'app/models/medida';
import { element } from 'protractor';
import { Pedido } from 'app/models/pedido';
import { Pieza } from 'app/models/pieza';
import { Abono } from 'app/models/abono';
import { AlertService } from 'ngx-alerts';

@Component({
  selector: 'app-principal',
  templateUrl: './principal.component.html',
  styleUrls: ['./principal.component.css']
})
export class PrincipalComponent implements OnInit {

  public findEstado = 'TODOS';
  public findCliente = '';
  public pedidos = [];
  public pedidoselect = {} as Pedido;
  public pedidoselectold = {} as Pedido;
  public newAbono = {} as Abono;
  fechaEntrega: any;
  public group: any;
  public usuario;
  public session;
  constructor(
    config: NgbModalConfig,
    private util: TextTilUtil,
    private msg: AlertService,
    private modalService: NgbModal,
    public _usuarioService: UsuarioService,
    public _pedidosService: PedidosService) {

  }
  changeEstado(estado: string) {
    this.findEstado = estado;
  }

  buscar() {
    console.log(this.findEstado, this.findCliente);
    switch (this.findEstado) {
      case 'TODOS':
        this.listarPedidosCliente(this.findCliente);
        break;
      case 'PENDIENTES':
        this.listarPedidosEstadoCliente('PENDIENTE',this.findCliente);
        break;
      case 'EN PROCESO':
        this.listarPedidosEstadoCliente('PROCESO',this.findCliente);
        break;
      case 'FINALIZADOS':
        this.listarPedidosEstadoCliente('FINALIZADO',this.findCliente);
        break;
      case 'ENTREGADOS':
        this.listarPedidosEstadoCliente('ENTREGADO',this.findCliente);
        break;
    }
  }

  ngOnInit() {
    this.limpiarAbono();
    this.listarPedidos();
    this.session = this._usuarioService.checkLogin();

    if (this.session) {
      this.usuario = this._usuarioService.getUsuarioSesion();
    }
  }



  getFotoSexo(sexo: string): string {
    if (sexo == 'M')
      return './assets/img/faces/hombre_64.png';
    else
      return './assets/img/faces/mujer_64.png'
  }

  valorStrint(valor: number): string {
    return this.util.valorStrint(valor);
  }

  limpiarAbono() {
    let nowDate = new Date();
    this.fechaEntrega = this.util.dateToJson(nowDate);
    this.newAbono = {} as Abono;
    this.newAbono.valor = 0;
    this.newAbono.usuario = {};
    this.newAbono.fecha = this.util.jsonToDate(this.fechaEntrega).getTime();
    this.newAbono.saldo = 0;
  }
  mostrar() {
    console.log('dato temporal---');
    console.log(this.pedidoselect);
    console.log('dato BD---');
    console.log(this.pedidoselectold);

  }

  UpdateMedidas(pieza: Pieza, valor: string) {
    pieza.estado = valor;
  }

  selecionarPedido(ped: Pedido) {
    this.pedidoselectold = ped;
    this.setearDatos(this.pedidoselect, ped);
  }

  updatePedido() {
    let pendiente = 0;
    let cortado = 0;
    let finalizados = 0;
    this.pedidoselect.piezas.forEach(element => {
      if (element.estado == 'PENDIENTE') {
        pendiente++;
      } else if (element.estado == 'CORTADO') {
        cortado++;
      } else {
        finalizados++;
      }
    });
    if (this.pedidoselect.piezas.length == finalizados) {
      this.pedidoselect.estado = 'FINALIZADO';
    } else if (this.pedidoselect.piezas.length == pendiente) {
      this.pedidoselect.estado = 'PENDIENTE';
    } else {
      this.pedidoselect.estado = 'PROCESO';
    }
    this._pedidosService.actualizar(this.pedidoselect);
    this.setearDatos(this.pedidoselectold, this.pedidoselect);
    $('#EditarModal').click();
    this.msg.success('ACTUALIZACION EXITOSA!');
  }

  cancelUpdatePedido() {
    this.setearDatos(this.pedidoselect, this.pedidoselectold);
    $('#EditarModal').click();

  }
  setearDatos(pedidoRecibe: Pedido, pedidoInfo: Pedido) {
    pedidoRecibe.id = pedidoInfo.id;
    pedidoRecibe.cliente = pedidoInfo.cliente;
    pedidoRecibe.estado = pedidoInfo.estado;
    pedidoRecibe.fecha = pedidoInfo.fecha;
    pedidoRecibe.fecha_entrega = pedidoInfo.fecha_entrega;
    pedidoRecibe.saldo = pedidoInfo.saldo;
    pedidoRecibe.valor = pedidoInfo.valor;
    pedidoRecibe.usuario = pedidoInfo.usuario;
    pedidoRecibe.usuario_update = this.usuario;
    pedidoRecibe.sexo = pedidoInfo.sexo;
    pedidoRecibe.piezas = [];
    pedidoInfo.piezas.forEach(element => {
      let newpieza = {} as Pieza;
      newpieza.id = element.id;
      newpieza.estado = element.estado;
      newpieza.imagen = element.imagen;
      newpieza.nombre = element.nombre;
      newpieza.sexo = element.sexo;
      newpieza.valor = element.valor;
      newpieza.medidas = [];
      element.medidas.forEach(element2 => {
        let newMedida = {} as Medida;
        newMedida.nombre = element2.nombre;
        newMedida.descripcion = element2.descripcion;
        newMedida.valor = element2.valor;
        newpieza.medidas.push(newMedida);
      });
      pedidoRecibe.piezas.push(newpieza);
    });
    pedidoRecibe.abonos = [];
    pedidoInfo.abonos.forEach(element => {
      let newAbono = {} as Abono;
      newAbono.fecha = element.fecha;
      newAbono.saldo = element.saldo;
      newAbono.usuario = element.usuario;
      newAbono.valor = element.valor;
      pedidoRecibe.abonos.push(newAbono);
    });
  }

  agruparLista(lista: [Medida]): any {
    let newList = []
    lista.forEach(element1 => {
      if (newList.length == 0) {
        let datos = {
          nombre: element1.nombre,
          cantidad: 1,
        }
        newList.push(datos)
      } else {
        let encontro = false;
        let nuevoelemento;
        newList.forEach(element2 => {
          if (element1.nombre == element2.nombre) {
            element2.cantidad = element2.cantidad + 1;
            encontro = true;
          }
        })
        if (!encontro) {
          let datos = {
            nombre: element1.nombre,
            cantidad: 1,
          }
          newList.push(datos);
        }

      }
    });
    return newList;
  }
  openAbono() {

  }
  addAbono() {
    if (this.newAbono.valor > 0) {
      if (this.newAbono.valor <= this.pedidoselect.saldo) {
        this.newAbono.fecha = this.util.jsonToDate(this.fechaEntrega).getTime();
        this.pedidoselect.saldo = this.pedidoselect.saldo - this.newAbono.valor;
        this.newAbono.saldo = this.pedidoselect.saldo;
        this.newAbono.usuario = this.usuario;
        this.pedidoselect.abonos.push(this.newAbono);
        this.updatePedido();
        $('#abonoModal').click();
        this.limpiarAbono();
        console.log(this.pedidoselect)
      } else {
        this.msg.warning('El Abono No puede ser mayor al Saldo');
      }
    } else {
      this.msg.danger('Ingrese Un Valor mayor de 0');
    }
  }

  TotalAbonos(abonos: [Abono]): number {

    let valor = 0;
    abonos.forEach(element1 => {
      valor = valor + element1.valor;
    });
    return valor;
  }

  listarPedidos() {
    this._pedidosService.listar().subscribe(pdidios => {
      this.pedidos = pdidios;
      if (pdidios.length == 0) {
        this.msg.warning('no se encontraron resultados');
      }

    })
  }
  listarPedidosEstadoCliente(estado:string,nombre:string){
    this._pedidosService.listarEstadosClientes(estado,nombre).subscribe(pdidios => {
      this.pedidos = pdidios;
      if (pdidios.length == 0) {
        this.msg.warning('no se encontraron resultados');
      }

    })
  }
  listarPedidosCliente(nombre:string){
    console.log('viene la locura...'+nombre)
    this._pedidosService.listarClientes(nombre).subscribe(pdidios => {
      this.pedidos = pdidios;
      if (pdidios.length == 0) {
        this.msg.warning('no se encontraron resultados');
      }

    })
  }
}
