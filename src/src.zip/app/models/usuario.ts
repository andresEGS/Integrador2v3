export class Usuario {
    id?: string;
    login?: string;
    password?: string;
    nombre?: string;
    email?: string;
    rol?: string;
}
