export class Persona {
    id?: string;
    nombre?: string;
    apellido?: string;
    telefono?: string;
}