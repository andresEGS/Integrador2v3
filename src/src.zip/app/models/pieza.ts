export class Pieza {
    id?: string;
    nombre?: string;
    medidas = [];
    descripcion?: string;
    sexo?: string;
    imagen?: string;
    valor?: number;
    estado?: string;
}