export class Medida {

    nombre?: string;
    descripcion?:string;
    valor?:string;
  
    
  }