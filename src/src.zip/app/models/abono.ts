export class Abono {
    saldo: number;
    valor: number;
    fecha: number;
    usuario:{};
    constructor() {

    }
    

}