import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';


import { AppRoutingModule } from './app.routing';
import { ComponentsModule } from './components/components.module';

import { AppComponent } from './app.component';

import { DashboardComponent } from './dashboard/dashboard.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { TableListComponent } from './table-list/table-list.component';
import { TypographyComponent } from './typography/typography.component';
import { IconsComponent } from './icons/icons.component';
import { MapsComponent } from './maps/maps.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { UpgradeComponent } from './upgrade/upgrade.component';
import {
  AgmCoreModule
} from '@agm/core';
import { AngularFireModule } from '@angular/fire';
import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';
import { environment } from 'environments/environment';
import { LoginComponent } from './login/login.component';
import { BrowserModule } from '@angular/platform-browser';
import { AngularFireStorageModule } from '@angular/fire/storage';
import { AngularFirestoreModule, AngularFirestore } from '@angular/fire/firestore';
import {  AngularFireDatabase } from '@angular/fire/database';
import { AuthGuard } from './utilidades/AuthGuard';
import { RedirectIfLoggedInGuard } from './utilidades/RedirectIfLoggedInGuard';
import { Messages } from './utilidades/Messages';
import { HttpClientModule } from '@angular/common/http';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { Page404Component } from './page404/page404.component';

import {
  MatButtonModule,
  MatInputModule,
  MatRippleModule,
  MatFormFieldModule,
  MatTooltipModule,
  MatSelectModule,
  MatDividerModule,
  MatSlideToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatRadioModule,
  MatListModule,
  MatIconModule,
  
} from '@angular/material';
import { CommonModule } from '@angular/common';
import { ModalModule } from 'angular-bootstrap-md';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TextTilUtil } from './utilidades/TextTilUtil';
import { ActualizarPerdidoComponent } from './modal/actualizar-perdido/actualizar-perdido.component';
import { AlertModule } from 'ngx-alerts';


@NgModule({
  imports: [
    CommonModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatRippleModule,
    MatInputModule,
    MatSelectModule,
    MatTooltipModule,
    MatSlideToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatRadioModule,
    MatDividerModule,
    MatListModule,
    ModalModule,
    NgbModule,
    MatIconModule,

    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    AngularFirestoreModule,
    AngularFireStorageModule,
    ReactiveFormsModule,
    HttpModule,
    ComponentsModule,
    HttpClientModule,
    RouterModule,    
    AngularFireModule.initializeApp(environment.firebase), 
    AlertModule.forRoot({ maxMessages: 5, timeout: 5000, position: 'right' }),
    MDBBootstrapModule.forRoot(), 
    AgmCoreModule.forRoot({
      apiKey: 'YOUR_GOOGLE_MAPS_API_KEY'
    })
  ],
  declarations: [
    AppComponent,
    AdminLayoutComponent,
    LoginComponent,
    Page404Component,
    ActualizarPerdidoComponent

  ],
  providers: [
    AuthGuard,
    RedirectIfLoggedInGuard,
    AngularFirestore,
    AngularFireDatabase,
    Messages,
    TextTilUtil,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
