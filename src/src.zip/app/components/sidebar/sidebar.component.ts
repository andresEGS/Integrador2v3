import { Component, OnInit } from '@angular/core';
import { Usuario } from 'app/models/usuario';
import { UsuarioService } from 'app/services/usuario.service';

declare const $: any;
declare interface RouteInfo {
    path: string;
    title: string;
    icon: string;
    class: string;
}
export const ROUTES: RouteInfo[] = [
  // { path: '/dashboard', title: 'Dashboard',  icon: 'dashboard', class: '' },
    { path: '/principal', title: 'Princial',  icon: 'dashboard', class: '' },
    { path: '/piezas', title: 'Piezas',  icon:'straighten', class: '' },
    { path: '/pedidos', title: 'Pedidos',  icon:'content_paste', class: '' },
    // { path: '/notifications', title: 'Usuarios',  icon:'person', class: '' },
    // { path: '/icons', title: 'Graficas',  icon:'pie_chart', class: '' }
];

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  menuItems: any[];
  public usuario = [] as Usuario;
  session = false;
  constructor(public _usuarioServicie: UsuarioService) { }

  ngOnInit() {
    this.menuItems = ROUTES.filter(menuItem => menuItem);
    this.session = this._usuarioServicie.checkLogin();
   
    if(this.session){
      this.usuario = this._usuarioServicie.getUsuarioSesion();
    }
   
  }


  isMobileMenu() {
      if ($(window).width() > 991) {
          return false;
      }
      return true;
  };
}
