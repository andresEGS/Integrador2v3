import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Usuario } from 'app/models/usuario';
import { UsuarioService } from 'app/services/usuario.service';
import { SESSION } from 'app/services/session';
import { Messages } from 'app/utilidades/Messages';
import { TextTilUtil } from 'app/utilidades/TextTilUtil';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public user
  public password
  public usuario = [] as Usuario;
  public isError=false;
  public msges='';
  session = false;

  constructor(private util:TextTilUtil, private msg: Messages, public _usuariopService: UsuarioService,
    private _router: Router, ) { }

  ngOnInit() {
   

  }

  iniciarSession() {
    if(this.user===''||this.user==undefined||this.user===null||this.user=='undefined'||
    this.password===''||this.password==undefined||this.password===null||this.password=='undefined'){
      this.msges='Igrese usuario y contraseña';
      this.isError=true;
      this.msg.msgWarning(this.msges);
    }else{
    this._usuariopService.login(this.user, this.password).subscribe(usuarios => {
      if (usuarios.length > 0) {
       
        this.usuario = usuarios[0];
        this.guardarSession();
        
        
      } else {
        this.msges='Usuario no negistrado';
        this.isError=true;
        this.msg.msgDanger(this.msges);
        
      }
    });

    if(this._usuariopService.checkLogin()){
      
        this.msg.msgSuccess('Bienbenido '+this.user.nombre);
    }
  }
}

  logOut() {
    localStorage.clear();
    this._router.navigate(['']);
    this.session = false;
  }

  guardarSession() {
    this.usuario
    var user = {
      nombre: this.usuario.nombre,
      email: this.usuario.email,
      login: this.usuario.login
    }
    ;
    localStorage.setItem(SESSION.usuarioSesion,this.util.encriptar(JSON.stringify(user)) );
    this._router.navigate(['/principal']);
  }




}
