import { Injectable } from "@angular/core";

import * as CryptoJS from 'crypto-js';



@Injectable()
export class TextTilUtil {


    constructor() {

    }


    public jsonToDate(json: any): Date {
        console.log('ejecutando jsonToDate ++')
        console.log('entra--->' + JSON.stringify(json))
        let midate: Date;
        midate = new Date(json.year, json.month, json.day);
        console.log('sale--->' + midate)
        return midate
    }

    public valorStrint(valor: number): string {
        return new Intl.NumberFormat().format(valor);
    }
    
    public dateToJson(fecha: Date): any {
        console.log('ejecutando dateToJson ---')
        console.log('entra--->' + fecha)
        let midate = {
            year: fecha.getFullYear(),
            month: fecha.getMonth(),
            day: fecha.getDate
                (),
        };
        console.log('sale--->' + JSON.stringify(midate))
        return midate;
    }

    public encriptar(text: string) {
        return CryptoJS.AES.encrypt(text, 'text-til').toString();
    }

    public desencriptar(text: string): string {
        return CryptoJS.AES.decrypt(text, 'text-til').toString(CryptoJS.enc.Utf8);
    }

    public encriptarSession(variable: string, text: string): void {
        sessionStorage.setItem(variable, this.encriptar(text));
    }

    public desencriptarSession(variable: string): any {
        let cryptoJSON = localStorage.getItem(variable)
        let result
        if (cryptoJSON != null) {
            result = JSON.parse(this.desencriptar(cryptoJSON));
        } else {
            result = 'no se encontro informacion';
            console.log(result);
        }
        return result;
    }

}