import { Injectable } from '@angular/core';

import { AngularFireDatabase } from '@angular/fire/database';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from '@angular/fire/firestore';

import { Observable, combineLatest, Subject } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';
import { Usuario } from '../models/usuario';
import { SESSION } from './session';
import { Router } from '@angular/router';
import { TextTilUtil } from 'app/utilidades/TextTilUtil';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {
  usuarioCollection: AngularFirestoreCollection<Usuario>;
  usuarioList: Observable<Usuario[]>;
  usuarioDoc: AngularFirestoreDocument<Usuario>;
  usuarioSesion = [] as Usuario;
  isLoggedIn: boolean = false;
  redirectUrl: string;

  constructor(private util: TextTilUtil,private _router: Router, public dbfairebase: AngularFirestore, public dba: AngularFireDatabase) { }

  listar() {
    this.usuarioCollection = this.dbfairebase.collection('usuarios');
    this.usuarioList = this.usuarioCollection.snapshotChanges().pipe(
      map(action => {
        return action.map(a => {
          const data = a.payload.doc.data() as Usuario;
          data.id = a.payload.doc.id;

          return data;
        }

        );
      }))
    return this.usuarioList;
  }

  getusuarionombre() {
    var citiesRef = this.dbfairebase.collection("usuarios");
    // let queryRef = citiesRef.where('state', '==', 'CA');

    this.dba.database.ref('/usuarios').once('value');

  }


  getUsuarioSesion() {
    let cryptoJSUsuario= localStorage.getItem(SESSION.usuarioSesion)
    if ( cryptoJSUsuario != null) {
      let usuarioSesion = JSON.parse(this.util.desencriptar(cryptoJSUsuario));
      this.usuarioSesion = usuarioSesion;
    } else {
      this.usuarioSesion = null;
    }
    return this.usuarioSesion;
  }

  checkLogin(): boolean {
    if (this.getUsuarioSesion() !== null) {
      return this.isLoggedIn = true;
    } else {
      return this.isLoggedIn = false;
    }
  }

  logOut() {
    localStorage.clear();
    this._router.navigate(['/login']);

  }



  login(login: string, password: string) {
    this.usuarioCollection = this.dbfairebase.collection('usuarios',
      ref => ref.where('login', '==', login)
        .where('password', '==', password))
    this.usuarioList = this.usuarioCollection.snapshotChanges().pipe(
      map(action => {
        return action.map(a => {
          const data = a.payload.doc.data() as Usuario;
          data.id = a.payload.doc.id;
          return data;
        }

        );
      }))
    return this.usuarioList;
  }
}
