export var SESSION = {

    usuarioSesion: 'usu_sesion',

}
