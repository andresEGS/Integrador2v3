export const environment = {
  production: true,
  firebase:{
    apiKey: "AIzaSyCHbFcYAhui7bUI7HKeXEhM89nkhzqWkkA",
    authDomain: "prueba-170ec.firebaseapp.com",
    databaseURL: "https://prueba-170ec.firebaseio.com",
    projectId: "prueba-170ec",
    storageBucket: "prueba-170ec.appspot.com",
    messagingSenderId: "188294235984",
    appId: "1:188294235984:web:2fffaf3d6f79dd28db4e55",
    measurementId: "G-L158XB0850"
  }
};
